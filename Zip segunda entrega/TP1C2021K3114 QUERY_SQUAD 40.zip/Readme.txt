Curso K3114
Numero de grupo 40
Integrantes:
Tolaba, Adrian - 1604417
Moyano Fontana, Maximiliano Ivan - 1761547
Bodirikyan, Cristian Artin - 1762175
Ramírez Marchisio, Tiago Alberto - 1763180
Email responsable del grupo: tramrezmarchisio@frba.utn.edu.ar